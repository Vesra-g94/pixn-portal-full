#!/bin/bash
export DISPLAY=:0.0
export LD_LIBRARY_PATH="/userdata/system/pro/.dep:${LD_LIBRARY_PATH}"

URL="https://pixn-retro.dedyn.io/"
ADDONS="/userdata/system/add-ons"
BUA_BASE="https://raw.githubusercontent.com/batocera-unofficial-addons/batocera-unofficial-addons/main"

CHROME="$ADDONS/google-chrome/GoogleChrome.AppImage"
BRAVE="$ADDONS/brave/brave.AppImage"
FIREFOX="$ADDONS/firefox/Firefox.AppImage"
LIBREWOLF="$ADDONS/librewolf/Librewolf.AppImage"
QBITTORRENT="$ADDONS/qbittorrent/qbittorrent.AppImage"

die_gui() {
    yad --error --title="Pix'n Portal" --text="$1" --width=430 --center
    exit 1
}

require_tools() {
    command -v yad >/dev/null 2>&1 || exit 1
    command -v curl >/dev/null 2>&1 || die_gui "curl is required but was not found."
    command -v mktemp >/dev/null 2>&1 || die_gui "mktemp is required but was not found."
}

run_bua_installer() {
    NAME="$1"
    INSTALL_URL="$2"
    EXPECTED_FILE="$3"

    TMPSCRIPT=$(mktemp /tmp/pixnportal-install-XXXXXX.sh) || return 1

    yad --info --title="Installing $NAME"         --text="Downloading and installing $NAME.\n\nThis may take a few minutes..."         --width=400 --center --timeout=3 --no-buttons

    curl -fsSL "$INSTALL_URL" -o "$TMPSCRIPT" || {
        rm -f "$TMPSCRIPT"
        yad --error --title="Install Failed"             --text="Could not download the $NAME installer."             --width=400 --center
        return 1
    }

    bash "$TMPSCRIPT"
    RESULT=$?
    rm -f "$TMPSCRIPT"

    if [ $RESULT -ne 0 ]; then
        yad --error --title="Install Failed"             --text="$NAME installer exited with an error."             --width=400 --center
        return 1
    fi

    if [ ! -f "$EXPECTED_FILE" ]; then
        yad --error --title="Install Failed"             --text="The installer finished, but $NAME was not found where expected."             --width=430 --center
        return 1
    fi

    chmod +x "$EXPECTED_FILE" 2>/dev/null

    yad --info --title="$NAME Installed"         --text="$NAME was installed successfully."         --width=380 --center --timeout=3 --no-buttons
}

find_browser() {
    if [ -x "$CHROME" ]; then
        echo chrome
    elif [ -x "$BRAVE" ]; then
        echo brave
    elif [ -x "$FIREFOX" ]; then
        echo firefox
    elif [ -x "$LIBREWOLF" ]; then
        echo librewolf
    fi
}

choose_and_install_browser() {
    CHOSEN=$(yad --list         --title="Pix'n Portal - Browser Required"         --text="Pix'n Portal needs a browser.\nChoose one to download and install:"         --column="Browser"         "Google Chrome" "Brave" "Firefox" "LibreWolf"         --width=430 --height=330 --center         --button="Cancel:1" --button="Install:0")

    [ $? -eq 0 ] || return 1
    CHOSEN=$(printf "%s" "$CHOSEN" | cut -d'|' -f1)

    case "$CHOSEN" in
        "Google Chrome")
            run_bua_installer "Google Chrome" "$BUA_BASE/chrome/chrome.sh" "$CHROME"
            ;;
        "Brave")
            run_bua_installer "Brave" "$BUA_BASE/brave/brave.sh" "$BRAVE"
            ;;
        "Firefox")
            run_bua_installer "Firefox" "$BUA_BASE/firefox/firefox.sh" "$FIREFOX"
            ;;
        "LibreWolf")
            run_bua_installer "LibreWolf" "$BUA_BASE/librewolf/librewolf.sh" "$LIBREWOLF"
            ;;
        *)
            return 1
            ;;
    esac
}

offer_qbittorrent() {
    [ -f "$QBITTORRENT" ] && return 0

    yad --question         --title="Pix'n Portal - qBittorrent"         --text="qBittorrent is not installed.\n\nPix'n Portal can install it now for torrent downloads."         --button="Not Now:1" --button="Install qBittorrent:0"         --width=440 --center

    [ $? -eq 0 ] || return 0

    run_bua_installer "qBittorrent"         "$BUA_BASE/qbittorrent/qbittorrent.sh"         "$QBITTORRENT"

    return 0
}

launch_portal() {
    case "$(find_browser)" in
        chrome)
            exec "$CHROME" --no-sandbox --no-first-run --no-default-browser-check --app="$URL"
            ;;
        brave)
            exec "$BRAVE" --no-sandbox --no-first-run --no-default-browser-check --app="$URL"
            ;;
        firefox)
            exec "$FIREFOX" --kiosk "$URL"
            ;;
        librewolf)
            exec "$LIBREWOLF" --kiosk "$URL"
            ;;
        *)
            die_gui "No supported browser was detected."
            ;;
    esac
}

require_tools

if [ -z "$(find_browser)" ]; then
    choose_and_install_browser || exit 1
    [ -n "$(find_browser)" ] || die_gui "Browser installation did not complete successfully."
fi

offer_qbittorrent
launch_portal
